<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
            text-transform: capitalize;
            text-decoration: none;
        }

        body {
            min-height: 100vh;
            position: relative;
        }
    
        header {
            position: relative;
            top: 0;
            left: 0;
            right: 0;
            background: #64CCC5;
            box-shadow: 0 5px 10px rgba(0, 0, 0, .1);
            padding: 0px 7%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            z-index: 1000;
            opacity: 0.8;
            width: 100%;
        }

        header .logo {
            font-weight: bolder;
            font-size: 25px;
            color: #04364A;
        }

        header .navbar ul {
            list-style: none;
            display: flex;
        }

        header .navbar ul li {
            position: relative;
            margin-right: 20px;
        }

        header .navbar ul li a {
            font-size: 18px;
            padding: 13px;
            color: #04364A;
            display: block;
            position: relative;
            overflow: hidden;
        }

        header .navbar ul li a::before {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background-color: white; /* Ubah warna sesuai kebutuhan */
            transition: width 0.3s ease; /* Tambahkan transisi untuk efek animasi */
        }

        header .navbar ul li a:hover::before {
            width: 100%;
        }

        header .navbar ul li ul {
            position: absolute;
            left: 0;
            width: 192px;
            background: #64CCC5;
            display: none;
            overflow-y: auto; /* Tambahkan ini untuk menambahkan scroll */
            max-height: 150px; /* Tentukan tinggi maksimum untuk scroll */
        }

        header .navbar ul li ul li {
            width: 100%;
            border-top: 1px solid rgba(0, 0, 0, .1);
        }

        header .navbar ul li ul li ul {
            left: 100%;
            top: 0;
        }

        header .navbar ul li:hover > ul {
            display: block; /* Mengubah initial menjadi block */
        }

        #menu {
            display: none;
        }

        header label {
            font-size: 18px;
            color: #04364A;
            cursor: pointer;
            display: none;
        }

        @media(max-width: 991px) {
            header {
                padding: 20px;
            }

            header label {
                display: initial;
            }

            header .navbar {
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: #64CCC5;
                border-top: 1px solid rgba(0, 0, 0, .1);
                display: none;
                width: 100%;
            }

            header .navbar ul {
                flex-direction: column;
            }

            header .navbar ul li {
                width: 100%;
            }

            header .navbar ul li ul {
                position: relative;
                width: auto;
            }

            header .navbar ul li ul li {
                background: #64CCC5;
            }

            header .navbar ul li ul li ul {
                width: auto;
                left: 100%;
            }

            #menu:checked ~ .navbar {
                display: initial; /* Mengubah + menjadi ~ */
            }

            header .navbar ul li a:hover::before {
                width: 100%; /* Menambahkan efek underline pada hover */
            }
        }

        /* Menghilangkan scroll bar */
        header .navbar ul li ul::-webkit-scrollbar {
            display: none;
        }
    </style>
</head>
<body>

<header>
    <input type="checkbox" id="menu">
    <label for="menu">MENU</label>
    <a href="#" class="logo">Toko Hitam</a>
    <nav class="navbar">
        <ul>
            <li><a href="home.php">Kembali</a></li>
            <li><a href="januari.php">Selanjutnya</a></li>
        </ul>
    </nav>
</header>

</body>
</html>
